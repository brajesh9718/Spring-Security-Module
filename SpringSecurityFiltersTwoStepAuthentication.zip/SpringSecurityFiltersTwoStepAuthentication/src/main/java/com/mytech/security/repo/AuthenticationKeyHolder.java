package com.mytech.security.repo;

import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Component;

@Component
public class AuthenticationKeyHolder {

	private Set<String> authenticationKeyList;

	public AuthenticationKeyHolder() {
		this.authenticationKeyList = new HashSet<>();
	}
	
	public void add(String key) {
		authenticationKeyList.add(key);
	}
	
	public boolean contains(String key) {
		return authenticationKeyList.contains(key);
	}
	
}
