package com.mytech.security.provider;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import com.mytech.security.authobj.AuthenticationToken;
import com.mytech.security.repo.AuthenticationKeyHolder;

@Component
public class AuthenticationTokenProvider implements AuthenticationProvider{

	@Autowired
	AuthenticationKeyHolder authenticationKeyHolder;
	
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {

		String tokenNumer = authentication.getName();
		System.out.println("AuthFinalToken :: "+tokenNumer);
		boolean flag = authenticationKeyHolder.contains(tokenNumer);
		if(flag) {
			return new AuthenticationToken(tokenNumer, null, null);
		}
		throw new BadCredentialsException("Failed !");
	}

	@Override
	public boolean supports(Class<?> auth) {
		// TODO Auto-generated method stub
		return AuthenticationToken.class.equals(auth);
	}

}
