package com.mytech.security.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mytech.security.entity.UserSecretKey;

@Repository
public interface SecretKeyRepo extends JpaRepository<UserSecretKey, Integer> {

	public UserSecretKey findByUsername(String username);
}
