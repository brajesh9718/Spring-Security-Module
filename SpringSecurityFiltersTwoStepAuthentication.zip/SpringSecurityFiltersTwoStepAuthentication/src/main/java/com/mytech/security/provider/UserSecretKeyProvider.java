package com.mytech.security.provider;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import com.mytech.security.authobj.SecretKeyTokenObj;
import com.mytech.security.entity.UserSecretKey;
import com.mytech.security.repo.SecretKeyRepo;

@Component
public class UserSecretKeyProvider implements AuthenticationProvider {

	@Autowired
	SecretKeyRepo secretKeyRepo;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		System.out.println("Inside authentication ......of UserSecretKeyProvider " + authentication.getName());
		String username  = authentication.getName();
		UserSecretKey usKey = secretKeyRepo.findByUsername(username);

		if (authentication.getName() != null) {
			return new SecretKeyTokenObj(authentication.getName(), authentication.getCredentials(), List.of(() -> "read"));
		}
		throw new BadCredentialsException("Failed Authentication....");
	}

	@Override
	public boolean supports(Class<?> authentication) {
		// TODO Auto-generated method stub
		return SecretKeyTokenObj.class.equals(authentication);
	}

}
