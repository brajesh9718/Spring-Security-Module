package com.mytech.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.mytech.security.dto.UserPassworDetailsDto;
import com.mytech.security.entity.User;
import com.mytech.security.repo.UserPasswordAuthRepo;

@Component
public class MyUserDetailsService implements UserDetailsService {

	@Autowired
	UserPasswordAuthRepo userPasswordAuthRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		 User user  =  userPasswordAuthRepo.findByUsername(username);
		 System.out.println(user);
		return new UserPassworDetailsDto(user);
	}

}
