package com.mytech.security.filter;

import java.io.IOException;
import java.util.Random;
import java.util.UUID;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.mytech.security.authobj.SecretKeyTokenObj;
import com.mytech.security.authobj.UserPasswordAuthToken;
import com.mytech.security.entity.UserSecretKey;
import com.mytech.security.repo.AuthenticationKeyHolder;
import com.mytech.security.repo.SecretKeyRepo;

@Component
public class UserPasswordAuthFilter extends OncePerRequestFilter {

	@Autowired
	AuthenticationManager authenticationManagerBean;

	@Autowired
	SecretKeyRepo secretKeyRepo;
	
	@Autowired
	AuthenticationKeyHolder authenticationKeyHolder;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		// GetParameters from User Requested Header
		String username = request.getHeader("username");
		String password = request.getHeader("password");
		String auth_key = request.getHeader("secret_key");
		System.out.println("User :: " + username + " Password :: " + password + " Auth_Key :: " + auth_key);

		// Generate own authObj class by extends UsernamePasswordAuthenticationToken
		if (auth_key == null) {
			System.out.println("auth_key :: is NUll" );
			UserPasswordAuthToken userPasswordAuthObj = new UserPasswordAuthToken(username, password);
			// Delegate authObj to AuthenticationManager for Authentication and internally
			// delegate to AuthenticationProvider
			Authentication authObjFromProvider = authenticationManagerBean.authenticate(userPasswordAuthObj);

			if (authObjFromProvider.isAuthenticated()) {
				// Generate a secret key...
				UserSecretKey userSecretKey = new UserSecretKey();
				userSecretKey.setUsername(username);
				userSecretKey.setKey(new Random().nextInt(999) * 1000 + "");
				// Save secret key to DB
				secretKeyRepo.save(userSecretKey);
			} 
		}else {
			//SecretKeyTokenObj secretKeyTokenObj = new SecretKeyTokenObj(username,auth_key);
			var auth = authenticationManagerBean.authenticate(new SecretKeyTokenObj(username,auth_key));
			
			//store token to DB
			String str = UUID.randomUUID().toString();
			System.out.println("Authorization Key :: "+ str);
			authenticationKeyHolder.add(str);
		    response.setHeader("Authorization", str);
				
		}
	}

	@Override
	protected boolean shouldNotFilter(HttpServletRequest req) throws ServletException {
		return !req.getServletPath().equals("/login");
	}

}
