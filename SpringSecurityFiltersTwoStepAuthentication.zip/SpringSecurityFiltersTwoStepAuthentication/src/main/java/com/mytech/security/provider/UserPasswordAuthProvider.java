package com.mytech.security.provider;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.mytech.security.authobj.UserPasswordAuthToken;
import com.mytech.security.service.MyUserDetailsService;

@Component
public class UserPasswordAuthProvider implements AuthenticationProvider {

	@Autowired
	MyUserDetailsService myUserDetailsService;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		System.out.println("Inside authentication ......of UserPasswordAuthProvider");

		UserDetails ud = myUserDetailsService.loadUserByUsername(authentication.getName());

		if (ud.getUsername() != null) {
			return new UserPasswordAuthToken(ud.getUsername(), ud.getPassword(), List.of(() -> "read"));
		}
		throw new BadCredentialsException("Failed Authentication....");
	}

	@Override
	public boolean supports(Class<?> authe) {
		// TODO Auto-generated method stub
		return UserPasswordAuthToken.class.equals(authe);
	}

}
