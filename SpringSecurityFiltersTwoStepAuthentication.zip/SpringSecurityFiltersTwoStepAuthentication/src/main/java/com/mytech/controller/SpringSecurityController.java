package com.mytech.controller;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringSecurityController {

	
	@RequestMapping("/hello")
	public String sayHello(Authentication auth) {
		return "Hello Guys..This Demo is for Two Step Authentication...!"+ auth.getName();
	}
}
