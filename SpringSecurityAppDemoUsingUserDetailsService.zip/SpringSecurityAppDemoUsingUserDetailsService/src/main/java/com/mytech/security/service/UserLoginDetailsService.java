package com.mytech.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import com.mytech.security.dto.UserLoginDto;
import com.mytech.security.entity.User;
import com.mytech.security.repo.UserLoginDetailsRepo;

public class UserLoginDetailsService implements UserDetailsService{

	@Autowired
	UserLoginDetailsRepo userLoginDetailsRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) {
		System.out.println("Requested User :: "+ username);
	   User user = userLoginDetailsRepo.findByUsername(username);
	   System.out.println(user);	   
		return new UserLoginDto(user);
	}

}
