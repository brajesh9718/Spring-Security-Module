package com.mytech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityAppDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityAppDemo1Application.class, args);
	}

}
