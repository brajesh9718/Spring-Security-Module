package com.mytech.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecurityController {

	
	@GetMapping("/hello")
	public String sayHello() {
		return "This is Spring Security Demo using Custome Service by implement UserDetailsService ....";
	}
}
