package com.mytech.controller;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class MyController {

	@Bean
	RestTemplate resTemplate() {
		return new RestTemplate();
	}

	@GetMapping("/")
	public String getHome() {
		System.out.println("Inside getHome() on Server....");
		return "index";
	}

}
