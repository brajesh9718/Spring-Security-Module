package com.mytech.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mytech.security.entity.User;
import com.mytech.security.service.repo.UserDetailsRepo;

@Service
public class MyUserService {

	@Autowired
	UserDetailsRepo userDetailsRepo ;
	
	public void addUser(User user) {
		userDetailsRepo.save(user);
	}
	
}
