package com.mytech.security.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mytech.security.entity.User;

public interface UserDetailsRepo extends JpaRepository<User, Integer> {

}
