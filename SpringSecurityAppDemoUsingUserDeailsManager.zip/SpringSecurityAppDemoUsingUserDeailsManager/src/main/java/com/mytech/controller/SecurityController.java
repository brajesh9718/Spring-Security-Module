package com.mytech.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mytech.security.entity.User;
import com.mytech.security.service.MyUserService;

@RestController
public class SecurityController {

	@Autowired
	MyUserService userService;
	
	@GetMapping("/index")
	public String sayHello() {
		return "Spring Security Using UserDetailsManager....";
	}
	
	
	@PostMapping("/createUser")
	public void addUser(@RequestBody User user) {
		System.out.println("Inside createUser Request......");
		userService.addUser(user);
	}
}
