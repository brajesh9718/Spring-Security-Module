package com.mytech.security.provider;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class VerifyFlowAuthenticationProvider implements AuthenticationProvider {

	@Autowired
	UserDetailsService userDetailsService;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {

		// User Input Credentials ....
		String passwordInput = authentication.getCredentials().toString();
		System.out.println("Input Credential :: " + passwordInput);

		// fetch from InMemomy/External Database
		UserDetails u = userDetailsService.loadUserByUsername(authentication.getName());
		// verify user by match...
		if (u != null) {
			return new UsernamePasswordAuthenticationToken(u.getUsername(), u.getPassword());
		}

		return null;
	}

	@Override
	public boolean supports(Class<?> authentication) {
		System.out.println("Inside support()---------");
		return UsernamePasswordAuthenticationToken.class.equals(authentication);
	}

}
