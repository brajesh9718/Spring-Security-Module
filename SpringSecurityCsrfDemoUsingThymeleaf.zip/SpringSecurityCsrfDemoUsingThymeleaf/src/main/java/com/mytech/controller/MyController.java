package com.mytech.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/csrfReq")
public class MyController {

	
	@GetMapping("/home")
	public String getHome() {
		System.out.println("Inside getHome() on Server....");
		return "home";
	}
	
	@PostMapping("/saveData")
	public String doSave(String uname) {
		System.out.println("Username ::" + uname);
		return "home";
	}
}
