package com.mytech.security.provider;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.mytech.security.token.MyAuthenticationToken;

@Component
public class MyCustomAuthenticationProvider implements AuthenticationProvider {

	@Value("${secret_key}")
	String secretKey;

	@Override
	public Authentication authenticate(Authentication authentication) {

		try {
			//FYI here the userName will be that which you pass from AuthenticateObj like using UserAndPassAuthentiationToken
			System.out.println("authentication.getName() :: " + authentication.getName());
			System.out.println("authentication.getCredentials() :: " + authentication.getCredentials());
			if (secretKey.equals(authentication.getName())) {
				return new MyAuthenticationToken(null, null, null);
			}
		} catch (Throwable e) {
			e.getMessage();
		}
		return null;
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return MyAuthenticationToken.class.equals(authentication);
	}

}
