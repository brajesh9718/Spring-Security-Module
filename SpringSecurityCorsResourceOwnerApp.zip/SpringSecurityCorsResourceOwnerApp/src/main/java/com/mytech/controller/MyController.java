package com.mytech.controller;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

@Controller
public class MyController {

	@Bean
	RestTemplate resTemplate() {
		return new RestTemplate();
	}

	@GetMapping("/myapp")
	public String getHome() {
		System.out.println("Inside getHome() on Server....");
		return "home";
	}

	@RequestMapping("/accessData")
	@ResponseBody
	@CrossOrigin
	public String accessData() {
		System.out.println("accessData Call...");
		return "Called Origin";
	}

	

	//Note: Cross Origin is used because 
	//Access to XMLHttpRequest at 'http://localhost:8080/accessData' from origin 'http://localhost:8083' 
	//has been blocked by CORS policy: No 'Access-Control-Allow-Origin' header is present on the requested resource.
	//When user call One Application Resource from another App it may chance of no response from calling resource 
	//on the Ajax call

	
}
