package com.mytech.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

@Controller
public class MyController {

	@Autowired
	private RestTemplate restTemplate;

	@Bean
	RestTemplate resTemplate() {
		return new RestTemplate();
	}

	@GetMapping("/myapp")
	public String getHome() {
		System.out.println("Inside getHome() on Server....");
		return "home";
	}

	@RequestMapping("/accessData")
	@ResponseBody
	public String accessData() {
		System.out.println("accessData Call...");
		Map<String, Integer> parameters = new HashMap<String, Integer>();
		parameters.put("id", 101);
		String response = restTemplate.getForObject("http://localhost:8080/{id}", String.class, parameters);
		return response;
	}

	@RequestMapping("/{id}")
	@ResponseBody
	public String restCall(@PathVariable int id) {
		System.out.println("Inside getCrossCalling :");
		return "Rest Call..." + id;
	}

	
}
